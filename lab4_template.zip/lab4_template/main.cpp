
#include "MathTree.h"

using namespace std;

int main()
{
    mt_test();
}
